package qst.imnu.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import qst.imnu.mapper.StucourceMapper;
import qst.imnu.pojo.Stucource;
import qst.imnu.pojo.StucourceExample;

import java.util.List;
@Controller
@RequestMapping("/stuco")
public class StucourceController {
    @Autowired
    private StucourceMapper sm;
    @RequestMapping("/stucoli")
    @ResponseBody
    public List<Stucource> getStucources(Integer stuid){
        StucourceExample se = new StucourceExample();
        se.createCriteria().andStunumberEqualTo(stuid);
        List<Stucource> stucources = sm.selectByExample(se);
        return stucources;
    }
}
