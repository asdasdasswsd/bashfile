package qst.imnu.controller;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;
import qst.imnu.mapper.SchoolMapper;
import qst.imnu.mapper.StudentMapper;
import qst.imnu.pojo.School;
import qst.imnu.pojo.SchoolExample;
import qst.imnu.pojo.Student;
import qst.imnu.pojo.Studentandcource;
import qst.imnu.service.SutdentService;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.File;
import java.io.IOException;
import java.util.Date;
import java.util.List;
import java.util.UUID;


/**
 * @author 刘建鑫
 */
@SuppressWarnings({"ALL", "AlibabaClassMustHaveAuthor"})
@Controller
@RequestMapping("/stu")
public class StudentController {
    @Autowired
    private SutdentService ss;
    @Autowired
    private SchoolMapper sm;
    @Autowired
    private StudentMapper stum;
    @RequestMapping("/sturegister")
    public ModelAndView stuRegister(Student stu, MultipartFile file) throws  Exception
    {
        String imgname = null;
        if(file != null)
        {
            imgname = uploadimg(file);
        }
        stu.setImg(imgname);
        stu.setRegistertime(new Date());
        int i = ss.studentRigister(stu);
        if (0 != i)
        {
            ModelAndView ma = new ModelAndView();
            System.out.println(stu);
            ma.addObject("register");
            ma.setViewName("home");
            return  ma;
        }
        return null;
    }
    public  String uploadimg(MultipartFile mf)
    {
        String filename = mf.getOriginalFilename();
        filename = UUID.randomUUID().toString()+filename.substring(filename.lastIndexOf("."));
        File f = new File("G:\\usershop\\mvc\\" + filename);
        try {
            mf.transferTo(f);
            return  filename;
        } catch (IOException e) {
            e.printStackTrace();
        }
        return  "error";
    }
    @RequestMapping("/forwordregister")
    public  ModelAndView forwordregister()
    {
        ModelAndView ma = new ModelAndView();
        ma.setViewName("register");
        List<School> schools = sm.selectByExample(new SchoolExample());
        ma.addObject("schools",schools);
        return ma;
    }
    @RequestMapping("/loign")
    public  ModelAndView login(Student stu)
    {
        ModelAndView mad = new ModelAndView();
        Student stulo = null;
        try {
            stulo=ss.studentLogin(stu);
            if (1 == stulo.getFlog()){
                mad.setViewName("roothome");
                mad.addObject("root",stulo);
            }
            else{
                mad.setViewName("home");
                mad.addObject("student",stulo);
            }
        } catch (Exception e){
            e.printStackTrace();
            mad.setViewName("login");
            mad.addObject("error","账号密码错误");
        }
        return  mad;
    }
    @RequestMapping("/addstudent")
    public void addstudent(Student stu, MultipartFile file) throws Exception
    {
        stu.setRegistertime(new Date());
        int i = ss.studentRigister(stu);
    }
    @ResponseBody
    @RequestMapping(value = "/studentlist")
    public PageInfo productbypage(HttpServletRequest req, HttpServletResponse resp, @RequestParam(required = true, defaultValue = "1") int page) throws ServletException, IOException {
        PageHelper.startPage(page, 3);
        List<Student> arrd = ss.selectstudentforlist(page);
        PageInfo<Student> pageInfo = new PageInfo<Student>(arrd);
        return pageInfo;
    }
    @ResponseBody
    @RequestMapping(value = "/showstudentandsource")
    public Studentandcource show(int number){
        Studentandcource studentandcource = stum.selectStudentAndCource(number);
        return studentandcource;
    }
    @PostMapping(value = "/addstudentbymenu")
    @ResponseBody
    public int addstudentbumenu(@RequestBody Student stu) throws Exception
    {
        System.out.println(stu);
        stu.setRegistertime(new Date());
        int i = ss.studentRigister(stu);
        return i;
    }
}
