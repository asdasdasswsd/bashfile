package qst.imnu.service;

import qst.imnu.pojo.Student;
import qst.imnu.pojo.Studentandcource;

import java.util.List;

public interface SutdentService {
    public int studentRigister(Student stu)throws Exception;
    public Student studentLogin(Student stu);
    List<Student> selectstudentforlist(int page);
    Studentandcource queryStudentandcource(int number);
}
