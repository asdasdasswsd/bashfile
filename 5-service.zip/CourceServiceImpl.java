package qst.imnu.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import qst.imnu.mapper.CourceMapper;
import qst.imnu.pojo.Cource;
import qst.imnu.pojo.CourceExample;

import java.util.List;

@Service
@Transactional
public class CourceServiceImpl implements CourceService{
    @Autowired
    private CourceMapper cm;
    @Override
    public int insertcource(Cource cou){
        int i = cm.insertSelective(cou);
        return i;
    }

    @Override
    public List<Cource> getAllCource() {
        List<Cource> arrsco = cm.selectByExample(new CourceExample());
        return arrsco;
    }
    @Override
    public int deleteCourceByNo(int no){
        int i = cm.deleteByPrimaryKey(no);
        System.out.println(i);
        return i;
    }
}
