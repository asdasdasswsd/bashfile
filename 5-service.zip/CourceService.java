package qst.imnu.service;

import qst.imnu.pojo.Cource;

import java.util.List;

public interface CourceService {
    int insertcource(Cource cou);
    List<Cource> getAllCource();
    int deleteCourceByNo(int no);
}
