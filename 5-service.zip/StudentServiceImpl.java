package qst.imnu.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import qst.imnu.mapper.StudentMapper;
import qst.imnu.pojo.Student;
import qst.imnu.pojo.StudentExample;
import qst.imnu.pojo.Studentandcource;

import java.util.List;

@Service
@Transactional
public class StudentServiceImpl implements SutdentService {
    @Autowired
    private StudentMapper sm;
    @Override
    public int studentRigister(Student stu) throws Exception {
        int i = sm.insertSelective(stu);
        return i;
    }
    @Override
    public Student studentLogin(Student stu) {
        StudentExample se = new StudentExample();
        se.createCriteria().andNumberEqualTo(stu.getNumber()).andPasswordEqualTo(stu.getPassword());
        List<Student> stuli = sm.selectByExample(se);
        return stuli == null?null:stuli.get(0);
    }
    @Override
    public List<Student> selectstudentforlist(int page) {
        List<Student> stulist = sm.selectByExample(new StudentExample());
        return  stulist;
    }
    @Override
    public Studentandcource queryStudentandcource(int number) {
        Studentandcource sad = sm.selectStudentAndCource(number);
        return sad;
    }
}
