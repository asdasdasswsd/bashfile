package qst.imnu.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import qst.imnu.mapper.JyMapper;
import qst.imnu.pojo.Jy;

@Service
@Transactional
public class JyServiceImpl implements JyService {
    @Autowired
    private JyMapper jm;
    @Override
    public int addJy(Jy y) {
        int i = jm.insertSelective(y);
        return i;
    }
}
