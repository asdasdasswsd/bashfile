package qst.imnu.service;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import qst.imnu.pojo.Jy;

public interface JyService {
    public int addJy(Jy y);
}
